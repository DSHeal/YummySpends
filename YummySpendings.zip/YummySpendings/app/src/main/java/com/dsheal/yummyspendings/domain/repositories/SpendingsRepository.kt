package com.dsheal.yummyspendings.domain.repositories

import com.dsheal.yummyspendings.domain.models.spendings.SpendingsModel
import io.reactivex.Completable
import io.reactivex.Flowable

interface SpendingsRepository {

    fun saveSpendingsInDatabase(spendings: List<SpendingsModel>): Completable

    fun listenSpendingsDatabase(): Flowable<List<SpendingsModel>>

}