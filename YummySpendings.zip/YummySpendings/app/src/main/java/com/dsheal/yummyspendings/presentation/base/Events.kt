package com.dsheal.yummyspendings.presentation.base

import androidx.navigation.NavDirections
import androidx.navigation.Navigator


//TODO понять, нафига этот класс и чем его заменить
class Events {

    data class MessageEvent(val message: String) : Event
    data class ErrorMessageEvent(val message: String) : Event

    sealed class NavigationEvent(val rootGraph: Boolean = false) : Event {

        class Up(rootGraph: Boolean) : NavigationEvent(rootGraph)

        class PopBackStack(
            rootGraph: Boolean = false,
            val destinationId: Int?,
            val inclusive: Boolean = false
        ) : NavigationEvent(rootGraph)

        class ToDirection(
            val direction: NavDirections,
            val extras: Navigator.Extras?,
            rootGraph: Boolean
        ) : NavigationEvent(rootGraph)

        class ToBottomNavigationItem(
            val bottomMenuItemResId: Int,
        ) : NavigationEvent()
    }

}