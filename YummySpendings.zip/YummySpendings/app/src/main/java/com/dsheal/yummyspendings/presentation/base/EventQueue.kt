package com.dsheal.yummyspendings.presentation.base

import androidx.activity.ComponentActivity
import androidx.annotation.MainThread
import androidx.fragment.app.Fragment
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.observe
import java.util.*

//TODO подумать, зачем нужны и чем заменить очереди и диспетчер событий
class EventQueue {

        private val liveData = MutableLiveData<Queue<Event>>()

        @MainThread
        fun offerEvent(event: Event) {
            val queue = liveData.value ?: LinkedList()
            queue.add(event)
            liveData.value = queue
        }

        fun observe(lifecycleOwner: LifecycleOwner, onEvent: (Event) -> Unit) {
            liveData.observe(lifecycleOwner) { consumeEvents(it, onEvent) }
        }


        fun observeForever(onEvent: (Event) -> Unit) {
            liveData.observeForever { consumeEvents(it, onEvent) }
        }

        private inline fun consumeEvents(events: Queue<Event>, consumeEvent: (Event) -> Unit) {
            while (events.isNotEmpty()) consumeEvent(events.remove())
        }
    }

    interface Event


    @Suppress("NOTHING_TO_INLINE")
    inline fun Fragment.observe(eventQueue: EventQueue, noinline onEvent: (Event) -> Unit) {
        eventQueue.observe(viewLifecycleOwner, onEvent)
    }

    @Suppress("NOTHING_TO_INLINE")
    inline fun ComponentActivity.observe(
        eventQueue: EventQueue,
        noinline onEvent: (Event) -> Unit
    ) {
        eventQueue.observe(this, onEvent)
    }

