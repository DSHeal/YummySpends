package com.dsheal.yummyspendings.data.database

object Migrations {
}