package com.dsheal.yummyspendings.presentation.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.setupWithNavController
import com.dsheal.yummyspendings.R
import com.dsheal.yummyspendings.presentation.MainViewModel
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

//    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mainViewModel = MainViewModel() // инизиализируем lazy создание viewModel
        setContentView(R.layout.activity_main)
        if (savedInstanceState == null) {
            setBottomNavigation()
        }
    }

    private fun setBottomNavigation() {

        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment

        val navController = navHostFragment.navController

        bottomNavigationView.setupWithNavController(
            navController
        )

//        bottomNavigationView.setOnNavigationItemSelectedListener {
//                NavigationUI.onNavDestinationSelected(it, navController)
//        }

    }

}