package com.dsheal.yummyspendings.presentation

import com.dsheal.yummyspendings.presentation.base.BaseViewModel
import javax.inject.Inject

class SpendingsViewModel @Inject constructor(
): BaseViewModel() {

}