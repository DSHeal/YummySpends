package com.dsheal.yummyspendings.presentation

class MainViewModel {
}