package com.dsheal.yummyspendings.domain.interactors

import com.dsheal.yummyspendings.domain.models.spendings.SpendingsModel
import com.dsheal.yummyspendings.domain.repositories.SpendingsRepository
import io.reactivex.Completable
import io.reactivex.Flowable

class SpendingsInteractor(
    private val spendingsRepository: SpendingsRepository) {

    private val logTag = "SpendingsInteractor"

    fun saveSpendingsInDatabase(spendings: List<SpendingsModel>): Completable =
        spendingsRepository.saveSpendingsInDatabase(spendings)

    fun listenSpendingsDatabase(): Flowable<List<SpendingsModel>> =
        spendingsRepository.listenSpendingsDatabase()

}