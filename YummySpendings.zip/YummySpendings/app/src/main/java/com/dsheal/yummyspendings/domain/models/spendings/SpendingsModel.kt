package com.dsheal.yummyspendings.domain.models.spendings

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize //посмотреть, зачем эта аннотация

data class SpendingsModel(
    val spendingId: Long,
    val userName: String = "",
    val spendingName: String = "",
    val spendingPrice: String = "",
    val spendingCategory: String = "",
    val purchaseDate: String = ""
): Parcelable

