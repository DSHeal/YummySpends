package com.dsheal.yummyspendings.presentation.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dsheal.yummyspendings.R
import com.dsheal.yummyspendings.domain.models.spendings.SpendingsModel
import javax.inject.Inject

class SpendingsListAdapter @Inject constructor():
    RecyclerView.Adapter<SpendingsListAdapter.SpendingsListViewHolder>() {

    private var spendings: List<SpendingsModel> = emptyList()


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): SpendingsListViewHolder {
        return SpendingsListViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.single_spending_recycler_item,parent, false))
    }

    override fun onBindViewHolder(
        holder: SpendingsListAdapter.SpendingsListViewHolder,
        position: Int
    ) = holder.bind(spendings[position])


    override fun getItemCount(): Int = spendings.size

    class SpendingsListViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){

         fun bind(item:SpendingsModel) {

        }
    }

}