package com.dsheal.yummyspendings.data.mappers

import com.dsheal.yummyspendings.data.database.spendings.SpendingsEntity
import com.dsheal.yummyspendings.domain.models.spendings.SpendingsModel

class SpendingsMapper {

    fun mapSpendingsModelToEntity(spendingsModel: List<SpendingsModel>): List<SpendingsEntity> =
        spendingsModel.map { mapSpendingsModelToEntity(it) }

    private fun mapSpendingsModelToEntity(spendingsModel: SpendingsModel):SpendingsEntity =
        SpendingsEntity(
            spendingId = spendingsModel.spendingId,
            userName = spendingsModel.userName,
            spendingName = spendingsModel.spendingName,
            spendingPrice = spendingsModel.spendingPrice,
            spendingCategory = spendingsModel.spendingCategory,
            purchaseDate = spendingsModel.purchaseDate
        )

    fun mapSpendingsEntityToModel(spendingsEntity: List<SpendingsEntity>): List<SpendingsModel> =
        spendingsEntity.map { mapSpendingsEntityToModel(it) }

    private fun mapSpendingsEntityToModel(spendingsEntity: SpendingsEntity): SpendingsModel =
        SpendingsModel(
            spendingId = spendingsEntity.spendingId,
            userName = spendingsEntity.userName,
            spendingName = spendingsEntity.spendingName,
            spendingPrice = spendingsEntity.spendingPrice,
            spendingCategory = spendingsEntity.spendingCategory,
            purchaseDate = spendingsEntity.purchaseDate
        )
}