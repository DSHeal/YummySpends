package com.dsheal.yummyspendings.data.dto

class SpendingsDto {


}