package com.dsheal.yummyspendings.di

import com.dsheal.yummyspendings.presentation.SpendingsViewModel
import dagger.Component
import javax.inject.Singleton

@Singleton
@Component
interface AppComponent {
    fun inject (spendingsViewModel: SpendingsViewModel)
}