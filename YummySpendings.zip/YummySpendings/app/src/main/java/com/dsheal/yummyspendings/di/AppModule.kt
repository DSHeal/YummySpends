package com.dsheal.yummyspendings.di

class AppModule {
}