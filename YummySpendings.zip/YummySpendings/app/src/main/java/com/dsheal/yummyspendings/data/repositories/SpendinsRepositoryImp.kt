package com.dsheal.yummyspendings.data.repositories

import com.dsheal.yummyspendings.data.database.Database
import com.dsheal.yummyspendings.data.mappers.SpendingsMapper
import com.dsheal.yummyspendings.domain.models.spendings.SpendingsModel
import com.dsheal.yummyspendings.domain.repositories.SpendingsRepository
import io.reactivex.Completable
import io.reactivex.Flowable

class SpendinsRepositoryImpl(
    private val database: Database,
    private val spendingsMapper: SpendingsMapper
) : SpendingsRepository {

    override fun saveSpendingsInDatabase(spendings: List<SpendingsModel>): Completable {
//понять наконец, почему Completable и что такое fromCallable, а также Flowable и сингл
        return Completable.fromCallable {
            database.spendingsDao().deleteSpendingsTable()
        }
            .andThen {
                database.spendingsDao()
                    .insertAllSpendings(spendingsMapper.mapSpendingsModelToEntity(spendings))
            }
    }

    override fun listenSpendingsDatabase(): Flowable<List<SpendingsModel>> {
        return database.spendingsDao().listenAllSpendings()
            .map {
                spendingsMapper.mapSpendingsEntityToModel(it)
            } // прочитать, что это такое distinctUntilChanged
            .distinctUntilChanged()

    }

}