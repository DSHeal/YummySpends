package com.dsheal.yummyspendings.presentation.base

import androidx.navigation.NavDirections
import androidx.navigation.Navigator

interface EventsDispatcher {

    val events: EventQueue

    fun showMessage(message: String) {
        events.offerEvent(Events.MessageEvent(message))
    }

    fun showError(message: String) {
        events.offerEvent(Events.ErrorMessageEvent(message))
    }

    fun navigateTo(
        direction: NavDirections,
        extras: Navigator.Extras? = null,
        rootGraph: Boolean = false
    ) {
        events.offerEvent(Events.NavigationEvent.ToDirection(direction, extras, rootGraph))
    }

    fun navigateUp(rootGraph: Boolean = false) {
        events.offerEvent(Events.NavigationEvent.Up(rootGraph))
    }
}
