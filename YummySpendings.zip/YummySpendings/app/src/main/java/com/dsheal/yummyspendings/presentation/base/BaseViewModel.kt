package com.dsheal.yummyspendings.presentation.base

import androidx.lifecycle.ViewModel
import io.reactivex.*
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.internal.subscriptions.SubscriptionHelper
import io.reactivex.schedulers.Schedulers

open class BaseViewModel {

    abstract class BaseViewModel : ViewModel(),
        EventsDispatcher {

        protected val compositeDisposable: CompositeDisposable = CompositeDisposable()

        override val events = EventQueue()

        override fun onCleared() {
            super.onCleared()
            compositeDisposable.clear()
        }

        protected fun asyncCompletable(): CompletableTransformer {
            return CompletableTransformer { upstream ->
                upstream
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnSubscribe {
                        compositeDisposable.add(it)
                    }
            }
        }

        protected fun <T> asyncMaybe(): MaybeTransformer<T, T> {
            return MaybeTransformer { upstream ->
                upstream
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnSubscribe { compositeDisposable.add(it) }
            }
        }

        protected fun <T> asyncSingle(): SingleTransformer<T, T> {
            return SingleTransformer { upstream ->
                upstream
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnSubscribe {
                        compositeDisposable.add(it)
                    }
            }
        }

        protected fun <T> asyncObservable(): ObservableTransformer<T, T> {
            return ObservableTransformer { upstream ->
                upstream
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnSubscribe { compositeDisposable.add(it) }
            }
        }

        protected fun <T> asyncFlowable(): FlowableTransformer<T, T> {
            return FlowableTransformer { upstream ->
                upstream
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnSubscribe { subscription ->
                        compositeDisposable.add(object : Disposable {
                            override fun isDisposed(): Boolean {
                                return subscription == SubscriptionHelper.CANCELLED
                            }

                            override fun dispose() {
                                subscription.cancel()
                            }
                        })
                    }
            }
        }
    }
}