package com.dsheal.yummyspendings.presentation

import androidx.fragment.app.Fragment

interface FragmentFactory {
    fun getTag(): String
    fun newInstance(): Fragment
}
