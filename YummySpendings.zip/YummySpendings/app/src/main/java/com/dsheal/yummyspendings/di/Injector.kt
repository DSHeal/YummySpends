package com.dsheal.yummyspendings.di

object Injector {
    var appComponent: AppComponent? = null

    fun plusAppComponent() {
        appComponent = DaggerAppComponent.builder()
            .build()
    }
}